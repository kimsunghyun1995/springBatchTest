package io.springbatch.springbatchlecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatchLectureApplicationTests {

    @Test
    void contextLoads() {
    }

}
